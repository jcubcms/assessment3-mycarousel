<?php
/*****************************************************
* My Carousel Slider
* https://varunv.sgedu.site/wordpress
* ----------------------------------------------------
* my-admin.php
* Code to customise the WordPress admin pages
******************************************************/

///////////////////
// ADMIN PAGES
///////////////////

// Add column in admin list view to show featured image
// http://wp.tutsplus.com/tutorials/creative-coding/add-a-custom-column-in-posts-and-custom-post-types-admin-screen/
function my_get_featured_image($post_ID) {
    $post_thumbnail_id = get_post_thumbnail_id($post_ID);
    if ($post_thumbnail_id) {
        $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview');
        return $post_thumbnail_img[0];
    }
}
function my_columns_head($defaults) {
    $defaults['featured_image'] = __('Featured Image', 'myCarousel');
    $defaults['category'] = __('Category', 'myCarousel');
    return $defaults;
}
function my_columns_content($column_name, $post_ID) {
    if ($column_name == 'featured_image') {
        $post_featured_image = my_get_featured_image($post_ID);
        if ($post_featured_image) {
            echo '<a href="'.get_edit_post_link($post_ID).'"><img src="' . $post_featured_image . '" alt="" style="max-width:100%;" /></a>';
        }
    }
    if ($column_name == 'category') {
        $post_categories = get_the_terms($post_ID, 'carousel_category');
        if ($post_categories) {
            $output = '';
            foreach($post_categories as $cat){
                $output .= $cat->name.', ';
            }
            echo trim($output, ', ');
        } else {
            echo 'No categories';
        }
    }
}
add_filter('manage_my_posts_columns', 'my_columns_head');
add_action('manage_my_posts_custom_column', 'my_columns_content', 10, 2);

// Extra admin field for image URL
function my_image_url(){
    global $post;
    $custom = get_post_custom($post->ID);
    $my_image_url = isset($custom['my_image_url']) ?  $custom['my_image_url'][0] : '';
    $my_image_url_openblank = isset($custom['my_image_url_openblank']) ?  $custom['my_image_url_openblank'][0] : '0';
    $my_image_link_text = isset($custom['my_image_link_text']) ?  $custom['my_image_link_text'][0] : '';
    $my_video_url = isset($custom['my_video_url']) ?  $custom['my_video_url'][0] : '';
    $my_video_aspect = isset($custom['my_video_aspect']) ?  $custom['my_video_aspect'][0] : '';
    ?>
    <p>
        <label><?php _e('Image URL', 'myCarousel'); ?>:</label>
        <input type="url" name="my_image_url" value="<?php echo $my_image_url; ?>" style="width: 100%"/> <br />
        <small><em><?php _e('(optional - leave blank for no link)', 'myCarousel'); ?></em></small>
    </p>

    <p>
        <label>
            <input type="checkbox" name="my_image_url_openblank" <?php if($my_image_url_openblank == 1){ echo ' checked="checked"'; } ?> value="1" /> <?php _e('Open link in new window?', 'myCarousel'); ?>
        </label>
    </p>

    <p>
        <label><?php _e('Button Text', 'myCarousel'); ?>:</label>
        <input type="text" name="my_image_link_text" value="<?php echo $my_image_link_text; ?>" style="width: 100%"/> <br />
        <small><em><?php _e('(optional - leave blank for default, only shown if using link buttons)', 'myCarousel'); ?></em></small>
    </p>

    <hr />

    <p><strong>Note: Using a video replaces the slide text &amp; button (if shown), Youtube &amp; Vimeo are supported</strong></p>

    <p>
        <label><?php _e('Video URL', 'myCarousel'); ?>:</label>
        <input type="text" name="my_video_url" value="<?php echo $my_video_url; ?>" style="width: 100%"/> <br />
        <small><em><?php _e('(use only the url, not the full embed code)', 'myCarousel'); ?></em></small>
    </p>

    <p>
        <label><?php _e('Video Aspect Ratio', 'myCarousel'); ?>:</label>
        <select name="my_video_aspect">
            <option value="embed-responsive-16by9" <?php if ($my_video_aspect == "embed-responsive-16by9") echo 'selected'; ?>>16:9</option>
            <option value="embed-responsive-4by3" <?php if ($my_video_aspect == "embed-responsive-4by3") echo 'selected'; ?>>4:3</option>
        </select> <br />
    </p>
    <?php
}
function my_admin_init_custpost(){
    add_meta_box("my_image_url", "Slide Options", "my_image_url", "my", "side", "low");
}
add_action("add_meta_boxes", "my_admin_init_custpost");
function my_mb_save_details(){
    global $post;
    if (isset($_POST["my_image_url"])) {
        $openblank = 0;
        if(isset($_POST["my_image_url_openblank"]) && $_POST["my_image_url_openblank"] == '1'){
            $openblank = 1;
        }
        update_post_meta($post->ID, "my_image_url", esc_url($_POST["my_image_url"]));
        update_post_meta($post->ID, "my_image_url_openblank", $openblank);
        update_post_meta($post->ID, "my_image_link_text", sanitize_text_field($_POST["my_image_link_text"]));
    }
    if (isset($_POST["my_video_url"])) {
        update_post_meta($post->ID, "my_video_url", esc_url($_POST["my_video_url"]));
        update_post_meta($post->ID, "my_video_aspect", sanitize_text_field($_POST["my_video_aspect"]));
    }
}
add_action('save_post', 'my_mb_save_details');


///////////////////
// CONTEXTUAL HELP
///////////////////
function my_contextual_help_tab() {
    $screen = get_current_screen();
    if( $screen->post_type === 'my'){
        $help = '<p>You can add a <strong>CPT Bootstrap Carousel</strong> image carousel using the shortcode <code>[image-carousel]</code>.</p>
                <p>You can read the full plugin documentation on the <a href="http://wordpress.org/plugins/myCarousel/" target="_blank">WordPress plugins page</a></p>
                <p>Most settings can be changed in the <a href="">settings page</a> but you can also specify options for individual carousels
                using the following settings:</p>

                <ul>
                <li><code>interval</code> <em>(default 5000)</em>
                <ul>
                <li>Length of time for the caption to pause on each image. Time in milliseconds.</li>
                </ul></li>

                <li><code>showcaption</code> <em>(default true)</em>
                <ul>
                <li>Whether to display the text caption on each image or not. true or false.</li>
                </ul></li>

                <li><code>showcontrols</code> <em>(default true)</em>
                <ul>
                <li>Whether to display the control arrows or not. true or false.</li>
                </ul></li>

                <li><code>orderby</code> and <code>order</code> <em>(default menu_order ASC)</em>
                <ul>
                <li>What order to display the posts in. Uses WP_Query terms.</li>
                </ul></li>

                <li><code>category</code> <em>(default all)</em>
                <ul>
                <li>Filter carousel items by a comma separated list of carousel category slugs.</li>
                </ul></li>

                <li><code>image_size</code> <em>(default full)</em>
                <ul>
                <li>WordPress image size to use, useful for small carousels</li>
                </ul></li>

                <li><code>id</code> <em>(default all)</em>
                <ul>
                <li>Specify the ID of a specific carousel post to display only one image.</li>';
        if(isset($_GET['post'])){
            $help .= '<li>The ID of the post you\'re currently editing is <strong>'.$_GET['post'].'</strong></li>';
        }
        $help .= '
            </ul></li>

        <li><code>twbs</code> <em>(default 4)</em>
        <ul>
        <li>Output markup for Twitter Bootstrap Version 2, 3 or 4.</li>
        </ul></li>
        </ul>
        ';
        $screen->add_help_tab( array(
            'id' => 'my_contextual_help',
            'title' => __('Carousel'),
            'content' => __($help)
                ) );
        }
    } // if( $screen->post_type === 'my'){
add_action('load-post.php', 'my_contextual_help_tab');
add_action('load-post-new.php', 'my_contextual_help_tab');
